package com.example.nycschoolsproject

object AppConstants {

    const val BASE_URL = "https://data.cityofnewyork.us/resource/"
}